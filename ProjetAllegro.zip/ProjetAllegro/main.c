#include <allegro.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <stdio.h>
#include "definition.h"
#include "Graphique.h"
#include "Animation.h"
#include "Vaisseau.h"
#include "Jeu.h"



int main() {
    //Initialisation d'Allegro et des ressources de base//
    initialiser_allegro();
    BITMAP *buffer = initialiser_buffer();

    //Variables pour les ressources graphiques//
    BITMAP *sprite_vaisseau = NULL;
    BITMAP *sprites_ennemis[4] = {NULL, NULL, NULL, NULL};
    BITMAP *fond = NULL;

    //Boucle principale du programme//
    int quitter_jeu = 0;
    while (!quitter_jeu) {
        //Variables pour le menu//
        int niveau_choisi = 1;
        char pseudo[20] = "";

        //Afficher le menu et récupérer le choix du joueur//
        int en_jeu = gerer_menu(buffer, &niveau_choisi, pseudo);

        //Si le joueur a quitté le menu sans vouloir jouer//
        if (!en_jeu) {
            quitter_jeu = 1;
            continue;  //Sortir de la boucle//
        }

        //Charger les ressources graphiques du jeu//
        charger_ressources_jeu(&sprite_vaisseau, sprites_ennemis, &fond);

        //Initialiser les structures de données du jeu//
        Vaisseau vaisseau;
        Tir tirs[MAX_TIRS];
        Effet effets[MAX_TIRS];
        Ennemi ennemis[MAX_ENNEMIS];
        Bonus bonus;
        Meteor meteors[MAX_METEORS]; // Ajout du tableau de météores
        initialiser_jeu(&vaisseau, tirs, effets, ennemis, &bonus, meteors);

        //Variables de jeu//
        int timer_apparition_ennemi = 0;
        int score = 0;
        int partie_terminee = 0;
        int espace_relache = 1;
        int ennemis_tues = 0;
        int ennemis_pour_vie = 15;

        //Variables pour le système de niveaux//
        int niveau_actuel = niveau_choisi == 0 ? 3 : niveau_choisi;
        int timer_niveau = 0;
        int niveau_termine = 0;
        int generer_ennemis = 1;
        int boss_genere = 0;

        //Position initiale du fond//
        int position_fond = 0;

        //Si mode boss => générer directement le boss//
        if (niveau_choisi == 0) {
            generer_ennemis = 0;
            apparition_boss(ennemis);
            boss_genere = 1;

            //Afficher un message d'avertissement pour le boss//
            textprintf_centre_ex(buffer, font, LARGEUR/2, HAUTEUR/2,
                               makecol(255, 0, 0), makecol(0, 0, 0),
                               "BOSS EN APPROCHE!!!!");
            blit(buffer, screen, 0, 0, 0, 0, LARGEUR, HAUTEUR);
            rest(2000); //Pause de 2 secondes//
        }

        //Boucle principale du jeu//
        while (!partie_terminee && !key[KEY_ESC]) {
            //Gestion des contrôles du joueur//
            gerer_controles(&vaisseau, tirs, effets, &espace_relache);

            //Update du fond défilant//
            update_fond(&position_fond);

            //Update de tous les éléments du jeu//
            update_jeu(tirs, effets, ennemis, &vaisseau, &bonus, meteors, &score, &ennemis_tues, &ennemis_pour_vie);

            //Compter les ennemis actifs et vérifier si le boss est vivant//
            int boss_vivant = 0;
            int ennemis_actifs = compter_ennemis_actifs(ennemis, &boss_vivant);

            //Gestion du niveau :progression, boss, fin de niveau//
            gerer_niveau(&timer_niveau, &niveau_actuel, &generer_ennemis, &niveau_termine,&boss_genere, ennemis, buffer, niveau_choisi, &score,&vaisseau, &partie_terminee, &ennemis_actifs);

            //Gestion de l'apparition des ennemis//
            gerer_apparition_ennemis(&timer_apparition_ennemi, ennemis, niveau_actuel, generer_ennemis);

            //Vérifier si le joueur est mort//
            if (vaisseau.vies <= 0) {
                partie_terminee = 1;
                // Ne pas afficher l'écran de fin ici, on le fera après la boucle
            }

            //Dessiner tous les éléments du jeu//
            dessiner_jeu(buffer, fond, position_fond, &vaisseau, sprite_vaisseau,
            tirs, effets, ennemis, sprites_ennemis, &bonus, meteors, score,
            pseudo, niveau_choisi, niveau_actuel, timer_niveau,
            generer_ennemis, ennemis_actifs, niveau_termine,
            boss_vivant, ennemis_tues, ennemis_pour_vie);

            //Limiter la vitesse du jeu//
            rest(16);
        }

        //Afficher l'écran de fin si la partie est terminée//
        if (partie_terminee) {
            // Déterminer si c'est une défaite (vies épuisées) ou une victoire
            int defaite = (vaisseau.vies <= 0);

                        if (defaite) {
                //Charger et afficher l'image de fin//
                BITMAP *image_fin = load_bitmap("fin.bmp", NULL);
                if (image_fin) {
                    //Si l'image a besoin d'être redimensionnée//
                    if (image_fin->w != LARGEUR || image_fin->h != HAUTEUR) {
                        stretch_blit(image_fin, buffer, 0, 0, image_fin->w, image_fin->h, 0, 0, LARGEUR, HAUTEUR);
                    } else {
                        blit(image_fin, buffer, 0, 0, 0, 0, LARGEUR, HAUTEUR);
                    }
                    destroy_bitmap(image_fin);
                } else {
                    //Si l'image ne peut pas être chargée=> utiliser la fonction dessiner_fin//
                    dessiner_fin(score, buffer);
                }

                //Afficher le pseudo et les informations supplémentaires//
                textprintf_centre_ex(buffer, font, LARGEUR/2, HAUTEUR/2 + 60,
                                   makecol(200, 200, 255), -1, "Joueur: %s", pseudo);

                textprintf_centre_ex(buffer, font, LARGEUR/2, HAUTEUR/2 + 90,
                                   makecol(200, 200, 200), -1, "Appuyez sur une touche pour revenir au menu");

                //Sauvegarder le score//
                sauvegarder_score(pseudo, score);

                textprintf_centre_ex(buffer, font, LARGEUR/2, HAUTEUR/2 + 120,
                                   makecol(0, 255, 0), -1, "Score sauvegardé dans le leaderboard!");

                //Afficher le score sur l'écran de fin//
                textprintf_centre_ex(buffer, font, LARGEUR/2, HAUTEUR/2 + 30,
                                   makecol(255, 255, 0), -1, "Score final: %d", score);

                blit(buffer, screen, 0, 0, 0, 0, LARGEUR, HAUTEUR);

                //Attendre que le joueur appuie sur une touche//
                clear_keybuf();
                readkey();
            } else {
                //Victoire//
                afficher_ecran_fin(buffer, score, pseudo);
            }
        }

        //Si l'utilisateur a appuyé sur ESC, quitter le jeu complètement//
        if (key[KEY_ESC]) {
            quitter_jeu = 1;
        }

        //Libérer les ressources pour cette partie//
        if (sprite_vaisseau) {
            destroy_bitmap(sprite_vaisseau);
        }
        sprite_vaisseau = NULL;

        for (int i = 0; i < 4; i++) { // Modifié de 3 à 4
            if (sprites_ennemis[i]) destroy_bitmap(sprites_ennemis[i]);
            sprites_ennemis[i] = NULL;
        }

        // Libérer le sprite des météores (un seul sprite partagé)
        if (meteors[0].sprite) {
            destroy_bitmap(meteors[0].sprite);
            // Mettre à NULL tous les pointeurs de sprite
            for (int i = 0; i < MAX_METEORS; i++) {
                meteors[i].sprite = NULL;
            }
        }

        if (fond) {
            destroy_bitmap(fond);
        }
        fond = NULL;
        //Attendre que toutes les touches soient relâchées avant de revenir au menu//
        clear_keybuf();
    }

    //Libérer le buffer et quitter//
    destroy_bitmap(buffer);
    allegro_exit();
    return 0;
}

END_OF_MAIN()